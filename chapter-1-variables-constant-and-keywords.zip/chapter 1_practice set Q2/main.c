// calculate the area of a circle and modify the same program to calculate the volume of a cylinder given its radius and height 

#include <stdio.h>

int main()
{
     int radius = 5;
     float pi = 5.21;
     printf("the area of circle is %f\n",pi*radius*radius);
     int height = 3; 
     printf("volume of this cylinder is %f\n", pi*radius*radius*height);
     return 0;
}
  
