/*write a c program to calculate area of a rectangle
a)using hard coded inputs */

#include <stdio.h>

int main()
{
   int length = 7,breadth = 7;
   int area = length*breadth;
   printf("the area of rectangle is %d",area);

    return 0;
}
 

