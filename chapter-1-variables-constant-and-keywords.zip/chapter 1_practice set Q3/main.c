// write a program to convert celcius (centigrade degrees temperature to farenhit)
#include <stdio.h>

int main()
{
    float celsius = 42,far;
    far = (celsius * 9/5) + 32;
    printf("the value of this celsius temperature in fahrenheit is %f",far);


    return 0;
}
