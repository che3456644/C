
#include <stdio.h>

int main()
{
    int a = 5;
    float b = 6.5;
    char c = 'u';
    int d = 9;
    int e = 56;
    printf("the value of a is %d\n",a);
    printf("the value of b is %f\n",b);
    printf("the value of c is %c\n",c);
    printf("the value of d is %d\n",d);
    printf("sum the value of a,b,d %f\n",a+b+d);
    printf("sum the value of a and b %f\n",a-b); 
    printf("sum the value of a and d is %d\n",e);
    return 0;
}

